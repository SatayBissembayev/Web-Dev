a = int(input("Enter a: "))

i = 1

while(i**2 <= a):
    print(i**2)
    i += 1