a = int(input("Enter a: "))
i = 0

while(2**i <= 50):
    print(2**i,end=" ")
    i += 1 