a = int(input("Enter a: "))
i = 0
while(True):
    if(2**i >= a):
        print(i)
        break
    i+=1
    
    
