n = int(input("Enter n: "))
sum = 0
if n > 0:
    for i in range(n):
        a = int(input())
        sum += a
print(sum)
