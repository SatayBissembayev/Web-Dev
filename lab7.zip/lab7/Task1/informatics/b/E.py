a = int(input("Enter a : "))
b = int(input("Enter b : "))

if(a > b):
    print(1)
elif(a == b):
    print(0)
else:
    print(2)