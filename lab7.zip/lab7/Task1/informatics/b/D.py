import math
a = int(input("Enter a : "))

if(a > 0):
    print(1)
elif(a == 0):
    print(0)
else:
    print(-1)    