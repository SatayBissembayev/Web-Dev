def findMin(a,b,c,d):
    return min(a,b,c,d)

print(findMin(100,200,1,134124))

