import math
def powerOfTwoNum(a,b):
    return math.pow(a,b)

print(powerOfTwoNum(2,4))