n = int(input("Enter n : "))
k = int(input("Enter k : "))

c = k % n

print(c)