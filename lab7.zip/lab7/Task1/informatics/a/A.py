import math

a = int(input("Enter a : "))
b = int(input("Enter b : "))

c =  math.sqrt(a**2 + b**2)

print(c)
