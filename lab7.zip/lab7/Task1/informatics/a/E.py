v = int(input("Enter v : "))
t = int(input("Enter t : "))

if(v > 0):
    print(v*t - 109)
else:
    print(109 + v*t)