def sum_double(a, b):
  if a != b:
    return a + b
  else:
    return (a + b) * 2