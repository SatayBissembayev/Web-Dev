if __name__ == '__main__':
    a = int(input())
    b = int(input())
    sum = a + b
    dif = a - b
    prod = a * b
    print(sum)
    print(dif)
    print(prod)
