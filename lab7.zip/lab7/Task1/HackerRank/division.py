if __name__ == '__main__':
    a = int(input())
    b = int(input())
    inte = a // b
    doub = a / b
    print(inte)
    print(doub)